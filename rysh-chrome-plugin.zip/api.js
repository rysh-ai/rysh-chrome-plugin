// api.js — Anthropic Messages API client

import authService from './authService.js';

const ANTHROPIC_URL     = 'https://api.anthropic.com/v1/messages';
const ANTHROPIC_VERSION = '2023-06-01';
const DEFAULT_MODEL     = 'claude-opus-4-5';
const MAX_TOKENS        = 1024;

const SYSTEM_PROMPT = `You are Rysh, an intelligent AI assistant integrated into the user's browser.
Help users with tasks, answer questions, explain concepts, and provide assistance while they browse.
Be concise, clear, and friendly. Format responses with markdown when it adds clarity.`;

class APIService {
  constructor() {
    this._history = [];
  }

  get history() { return [...this._history]; }

  clearHistory() { this._history = []; }

  async sendMessage(userMessage, _options = {}) {
    const token = await authService.getToken();
    if (!token) throw new Error('Not authenticated — please set your API key.');

    this._history.push({ role: 'user', content: userMessage });

    const body = {
      model:      DEFAULT_MODEL,
      max_tokens: MAX_TOKENS,
      system:     SYSTEM_PROMPT,
      messages:   this._history,
    };

    const response = await fetch(ANTHROPIC_URL, {
      method: 'POST',
      headers: {
        'Content-Type':                              'application/json',
        'x-api-key':                                 token,
        'anthropic-version':                         ANTHROPIC_VERSION,
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      let msg = `API error ${response.status}`;
      try {
        const err = await response.json();
        msg = err?.error?.message || msg;
      } catch (_) {}
      // Remove the optimistically-added user message on failure
      this._history.pop();
      throw new Error(msg);
    }

    const data = await response.json();
    const text = data.content?.[0]?.text ?? '';

    this._history.push({ role: 'assistant', content: text });

    return { text, model: data.model, usage: data.usage };
  }
}

export const apiService = new APIService();
export default apiService;
