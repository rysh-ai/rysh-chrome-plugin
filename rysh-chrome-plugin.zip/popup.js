// popup.js — Rysh AI popup controller

import authService from './authService.js';
import apiService  from './api.js';

// ── DOM references ────────────────────────────────────────────────────────────
const setupScreen     = document.getElementById('setup-screen');
const chatScreen      = document.getElementById('chat-screen');
const openAuthBtn     = document.getElementById('open-auth-btn');
const newChatBtn      = document.getElementById('new-chat-btn');
const menuBtn         = document.getElementById('menu-btn');
const dropdownMenu    = document.getElementById('dropdown-menu');
const menuPageContext = document.getElementById('menu-page-context');
const menuSignout     = document.getElementById('menu-signout');
const messagesArea    = document.getElementById('messages-area');
const emptyState      = document.getElementById('empty-state');
const loadingIndicator= document.getElementById('loading-indicator');
const errorBanner     = document.getElementById('error-banner');
const errorText       = document.getElementById('error-text');
const errorClose      = document.getElementById('error-close');
const messageInput    = document.getElementById('message-input');
const sendBtn         = document.getElementById('send-btn');

// ── State ─────────────────────────────────────────────────────────────────────
let isLoading = false;

// ── Auth state ────────────────────────────────────────────────────────────────
authService.onAuthStateChanged(user => {
  if (user) {
    showScreen('chat');
  } else {
    showScreen('setup');
  }
});

// ── Screen management ─────────────────────────────────────────────────────────
function showScreen(name) {
  setupScreen.classList.toggle('hidden', name !== 'setup');
  chatScreen.classList.toggle('hidden',  name !== 'chat');
}

// ── Auth button ───────────────────────────────────────────────────────────────
openAuthBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'OPEN_AUTH' });
});

// ── New chat ──────────────────────────────────────────────────────────────────
newChatBtn.addEventListener('click', () => {
  apiService.clearHistory();
  clearMessages();
  hideError();
  closeMenu();
});

// ── Menu ──────────────────────────────────────────────────────────────────────
menuBtn.addEventListener('click', e => {
  e.stopPropagation();
  dropdownMenu.classList.toggle('open');
});

document.addEventListener('click', () => closeMenu());

function closeMenu() {
  dropdownMenu.classList.remove('open');
}

// ── Page context ──────────────────────────────────────────────────────────────
menuPageContext.addEventListener('click', async () => {
  closeMenu();
  const res = await chrome.runtime.sendMessage({ type: 'GET_PAGE_CONTEXT' });
  const ctx  = res?.context;
  if (!ctx) return;

  let contextMsg = `[Page context]\nTitle: ${ctx.title}\nURL: ${ctx.url}`;
  if (ctx.description) contextMsg += `\nDescription: ${ctx.description}`;
  if (ctx.selected)    contextMsg += `\n\nSelected text:\n${ctx.selected}`;

  messageInput.value = contextMsg + '\n\n';
  messageInput.dispatchEvent(new Event('input'));
  messageInput.focus();
  // Place cursor at end
  messageInput.setSelectionRange(messageInput.value.length, messageInput.value.length);
});

// ── Sign out ──────────────────────────────────────────────────────────────────
menuSignout.addEventListener('click', async () => {
  closeMenu();
  await authService.signOut();
  apiService.clearHistory();
  clearMessages();
});

// ── Input auto-resize ─────────────────────────────────────────────────────────
messageInput.addEventListener('input', () => {
  messageInput.style.height = 'auto';
  messageInput.style.height = Math.min(messageInput.scrollHeight, 120) + 'px';
  sendBtn.disabled = messageInput.value.trim() === '' || isLoading;
});

// ── Send on Enter ─────────────────────────────────────────────────────────────
messageInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!sendBtn.disabled) sendMessage();
  }
});

sendBtn.addEventListener('click', () => {
  if (!sendBtn.disabled) sendMessage();
});

// ── Error close ───────────────────────────────────────────────────────────────
errorClose.addEventListener('click', hideError);

// ── Send message ──────────────────────────────────────────────────────────────
async function sendMessage() {
  const text = messageInput.value.trim();
  if (!text || isLoading) return;

  hideError();
  isLoading = true;
  sendBtn.disabled = true;

  // Clear input
  messageInput.value = '';
  messageInput.style.height = 'auto';

  // Hide empty state
  emptyState.style.display = 'none';

  // Append user message
  appendMessage('user', text);

  // Show loading
  loadingIndicator.classList.remove('hidden');
  scrollToBottom();

  try {
    const { text: reply } = await apiService.sendMessage(text);
    loadingIndicator.classList.add('hidden');
    appendMessage('assistant', reply);
  } catch (err) {
    loadingIndicator.classList.add('hidden');
    showError(err.message);
  } finally {
    isLoading = false;
    sendBtn.disabled = messageInput.value.trim() === '';
  }
}

// ── DOM helpers ───────────────────────────────────────────────────────────────
function appendMessage(role, text) {
  const wrapper = document.createElement('div');
  wrapper.className = `message ${role}`;

  const bubble = document.createElement('div');
  bubble.className = 'message-bubble';
  bubble.innerHTML = renderMarkdown(text);

  const meta = document.createElement('div');
  meta.className = 'message-meta';
  meta.textContent = formatTime(new Date());

  wrapper.appendChild(bubble);
  wrapper.appendChild(meta);
  messagesArea.appendChild(wrapper);
  scrollToBottom();
}

function clearMessages() {
  // Remove all message elements but keep empty-state
  const messages = messagesArea.querySelectorAll('.message');
  messages.forEach(m => m.remove());
  emptyState.style.display = '';
}

function scrollToBottom() {
  messagesArea.scrollTop = messagesArea.scrollHeight;
}

function showError(msg) {
  errorText.textContent = msg;
  errorBanner.classList.remove('hidden');
}

function hideError() {
  errorBanner.classList.add('hidden');
  errorText.textContent = '';
}

function formatTime(date) {
  return date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

// ── Minimal markdown renderer ─────────────────────────────────────────────────
function renderMarkdown(text) {
  // Escape HTML first
  let html = escapeHtml(text);

  // Fenced code blocks
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, _lang, code) => {
    return `<pre><code>${code.trim()}</code></pre>`;
  });

  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // Bold
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');

  // Italic
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');

  // Unordered lists
  html = html.replace(/^[ \t]*[-*+] (.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');

  // Paragraphs: double newlines
  html = html.replace(/\n\n+/g, '</p><p>');

  // Single newlines (outside blocks)
  html = html.replace(/\n/g, '<br>');

  return `<p>${html}</p>`;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
