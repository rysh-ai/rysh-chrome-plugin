// authService.js
// Auth service stub — designed to be swapped with Firebase Auth.
// The interface mirrors firebase.auth() so popup.js and auth.js need no changes
// when Firebase is integrated: just replace this file's implementation.

import { storage } from './storage.js';

class AuthService {
  constructor() {
    this._listeners = [];
    this._currentUser = null;
    this._initialized = false;
  }

  // Initialize: restore persisted auth state.
  // Call once at extension startup.
  async initialize() {
    if (this._initialized) return this._currentUser;
    const token = await storage.get('auth_token');
    const user  = await storage.get('auth_user');
    if (token && user) {
      this._currentUser = user;
    }
    this._initialized = true;
    return this._currentUser;
  }

  // ── Stable interface (same signatures Firebase Auth uses) ──────────────────

  get currentUser() { return this._currentUser; }

  async isAuthenticated() {
    await this.initialize();
    return this._currentUser !== null;
  }

  // Returns the stored API key / id-token.
  async getToken() {
    return storage.get('auth_token');
  }

  async getCurrentUser() {
    await this.initialize();
    return this._currentUser;
  }

  // Mirrors firebase.auth().onAuthStateChanged(callback).
  // Returns an unsubscribe function.
  onAuthStateChanged(callback) {
    this._listeners.push(callback);
    // Emit current state immediately (async, as Firebase does).
    this.getCurrentUser().then(user => callback(user));
    return () => {
      this._listeners = this._listeners.filter(l => l !== callback);
    };
  }

  async signOut() {
    await storage.remove(['auth_token', 'auth_user', 'auth_time']);
    this._currentUser = null;
    this._notify(null);
  }

  // ── Stub-specific sign-in (replaced by Firebase methods later) ────────────

  // TODO (Firebase): replace with signInWithGoogle() / signInWithEmailAndPassword()
  async signInWithApiKey(apiKey) {
    const key = (apiKey || '').trim();
    if (!key) throw new Error('API key is required');
    if (!key.startsWith('sk-ant-')) {
      throw new Error('Invalid API key format — Anthropic keys start with sk-ant-');
    }

    const user = {
      uid: 'api-key-user',
      displayName: 'API Key User',
      email: '',
      provider: 'api-key',
    };

    await storage.set({
      auth_token: key,
      auth_user:  user,
      auth_time:  Date.now(),
    });

    this._currentUser = user;
    this._notify(user);
    return user;
  }

  _notify(user) {
    this._listeners.forEach(cb => cb(user));
  }
}

export const authService = new AuthService();
export default authService;
